<?php
include "config.php";

function add_books($conn)
{
    if ($_SERVER["REQUEST_METHOD"] === 'POST') {
        $book_name = $_POST['book_name'] ?? '';
        $author = $_POST['author'] ?? '';
        $published_year = $_POST['published_year'] ?? '';
        $genre = $_POST['genre'] ?? '';
        $summary = $_POST['summary'] ?? '';

        if (empty($book_name) || empty($author) || empty($published_year) || empty($genre) || empty($summary)) {
            echo "All fields are required";
            return;
        }

        $stmt = $conn->prepare("INSERT INTO books(book_name, author, published_year, genre, summary) VALUES (?,?,?,?,?)");
        $stmt->bind_param("sssss", $book_name, $author, $published_year, $genre, $summary);

        if ($stmt->execute()) {
            echo json_encode(1);
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Invalid request methoad.";
    }
}
add_books($conn);
