<?php
include 'config.php';

function add_school($conn)
{
    if ($_SERVER["REQUEST_METHOD"] === 'POST') {
        $school_name = $_POST['school_name'] ?? '';
        $contact_number = $_POST['contact_number'] ?? '';
        $email = $_POST['email'] ?? '';
        $address = $_POST['address'] ?? '';
        $established_year = $_POST['established_year'] ?? '';
        $students_count = $_POST['students_count'] ?? '';
        $website_url = $_POST['website_url'] ?? '';

        if (empty($school_name) || empty($contact_number) || empty($email) || empty($address) || empty($established_year) || empty($students_count) || empty($website_url)) {
            echo "All fields are required";
            return;
        }

        $stmt = $conn->prepare("INSERT INTO schools(school_name, contact_number, email, address, established_year, students_count, website_url) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssss", $school_name, $contact_number, $email, $address, $established_year, $students_count, $website_url);

        if ($stmt->execute()) {
            echo json_encode(1);
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Invalid request method.";
    }
}


add_school($conn);

$conn->close();

?>
