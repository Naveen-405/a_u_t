<?php
include "config.php";

function assign_book($conn)
{
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $fk_school_id = isset($_POST['school_id']) ? (int)$_POST['school_id'] : 0;
        $books_json = isset($_POST['books']) ? $_POST['books'] : '[]';
        $books = json_decode($books_json, true);

        
        if ($fk_school_id <= 0 || empty($books)) {
            echo json_encode(["status" => 0, 'message' => 'Invalid school ID or no books selected']);
            return;
        }

        $school_name_query = $conn->prepare("SELECT school_name FROM schools WHERE pk_school_id = ?");
        $school_name_query->bind_param("i", $fk_school_id);
        $school_name_query->execute();
        $school_name_result = $school_name_query->get_result();
        $school_name = $school_name_result->fetch_assoc()['school_name'];
        $school_name_query->close();

        $delete_query = $conn->prepare("DELETE FROM school_books WHERE fk_school_id = ?");
        if ($delete_query === false) {
            echo json_encode(['status' => 0, 'message' => 'Prepare failed: ' . $conn->error]);
            return;
        }

        $delete_query->bind_param("i", $fk_school_id);
        $delete_query->execute();
        $delete_query->close();

        $insert_query = $conn->prepare("INSERT INTO school_books (fk_school_id, fk_book_id) VALUES (?, ?)");
        if ($insert_query === false) {
            echo json_encode(['status' => 0, 'message' => 'Prepare failed: ' . $conn->error]);
            return;
        }

        foreach ($books as $book) {
            $fk_book_id = (int)$book['value']; 
            $insert_query->bind_param("ii", $fk_school_id, $fk_book_id);
            $insert_query->execute();
        }
        $insert_query->close();

        $assigned_books = [];
        foreach ($books as $book) {
            $assigned_books[] = ['id' => $book['value'], 'name' => $book['label']];
        }

        echo json_encode([
            'status' => 1,
            'message' => 'Books assigned successfully',
            'school_name' => $school_name,
            'assigned_books' => $assigned_books
        ]);

        $conn->close();
    } else {
        echo json_encode(['status' => 0, 'message' => 'Invalid request method']);
    }
}

assign_book($conn);
?>
