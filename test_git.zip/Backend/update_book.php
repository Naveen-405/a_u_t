<?php 
include "config.php";

function update_book($conn) {
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $pk_book_id = (int) $_POST['pk_book_id'] ?? '';
        $book_name = $_POST['book_name'] ?? '';
        $author = $_POST['author'] ?? '';
        $published_year = $_POST['published_year'] ?? '';
        $genre = $_POST['genre'] ?? '';
        $summary = $_POST['summary'] ?? '';

        if (empty($book_name) || empty($author) || empty($published_year) || empty($genre) || empty($summary)) {
            echo "All fields are required";
            return;
        }

        // Prepare the SQL statement
        $stmt = $conn->prepare("UPDATE books SET book_name=?, author=?, published_year=?, genre=?, summary=? WHERE pk_book_id=?");
        if ($stmt === false) {
            // Output the error message if prepare() fails
            echo "Error preparing the SQL statement: " . $conn->error;
            return;
        }

        // Bind the parameters
        $stmt->bind_param("sssssi", $book_name, $author, $published_year, $genre, $summary, $pk_book_id);

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(1); // Success response
        } else {
            echo "Error executing the statement: " . $stmt->error; // Output error details
            echo json_encode(0);
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Invalid request method";
    }
}

// Call the update_book function
update_book($conn);
?>
