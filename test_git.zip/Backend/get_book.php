<?php
include "config.php";

function get_books($conn)
{
    $result = $conn->query("SELECT * FROM books");

    if ($result) {
        $books = [];
        while ($row = $result->fetch_assoc()) {
            $books[] = $row;
        }
        header('Content-Type:application/json');
        echo json_encode($books);
    } else {
        echo json_encode(["error" => "no data"]);
    }
}
get_books($conn)

?>