<?php 
include "config.php";

function delete_school($conn)
{
    if($_SERVER["REQUEST_METHOD"] === "POST"){
        $pk_school_id = (int)($_POST['pk_school_id'] ?? 0);

        if($pk_school_id <= 0){
            echo json_encode(["status" => "error", "message"=> "Invaild school ID"]);
            return;
        }

        $stmt = $conn->prepare("DELETE FROM schools WHERE pk_school_id = ?");
        $stmt->bind_param("i", $pk_school_id);

        if($stmt->execute()){
            echo json_encode(1);
        }
        else {
            echo json_encode(0);        
        }

        $stmt->close();
    } else{
        echo json_encode(["status"=> "error", "messgae"=> "Invaild request method"]);
    };
}
delete_school($conn);
?>