<?php
include 'config.php';

function assign_books($conn)
{
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $school_id = isset($_POST['school_id']) ? (int)$_POST['school_id'] : 0;
        $books = isset($_POST['books']) ? $_POST['books'] : [];

        if ($school_id <= 0 || empty($books)) {
            echo json_encode(['status' => 0, 'message' => 'Invalid school ID or no books selected']);
            return;
        }

        // Clear previous book assignments for this school
        $delete_query = $conn->prepare("DELETE FROM school_books WHERE school_id = ?");
        $delete_query->bind_param("i", $school_id);
        $delete_query->execute();
        $delete_query->close();

        // Insert new book assignments
        $insert_query = $conn->prepare("INSERT INTO school_books (school_id, book_id) VALUES (?, ?)");
        foreach ($books as $book_id) {
            $insert_query->bind_param("ii", $school_id, $book_id);
            $insert_query->execute();
        }
        $insert_query->close();

        echo json_encode(['status' => 1, 'message' => 'Books assigned successfully']);
    } else {
        echo json_encode(['status' => 0, 'message' => 'Invalid request method']);
    }
}

assign_books($conn);
$conn->close();
?>
