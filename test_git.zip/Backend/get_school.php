<?php 
include "config.php";

function get_schools($conn){
  $result = $conn->query("SELECT * FROM schools");
  
  if($result){
    $schools = [];

    while($row = $result->fetch_assoc()){
        $schools[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($schools);
  }
  else {
    echo json_encode(["error" => "No data"]);
  }
}
get_schools($conn);

$conn->close();

?>