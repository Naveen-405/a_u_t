<?php
include "config.php";

function update_school($conn)
{
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        
        $pk_school_id = (int)($_POST['pk_school_id'] ?? '');
        $school_name = $_POST['school_name'] ?? '';
        $contact_number = $_POST['contact_number'] ?? '';
        $email = $_POST['email'] ?? '';
        $address = $_POST['address'] ?? '';
        $established_year = $_POST['established_year'] ?? '';
        $students_count = (int)($_POST['students_count'] ?? 0); // Ensure this is an integer
        $website_url = $_POST['website_url'] ?? '';

        $stmt = $conn->prepare("UPDATE schools SET school_name = ?, contact_number = ?, email = ?, address = ?, established_year = ?, students_count = ?, website_url = ? WHERE pk_school_id = ?");
        $stmt->bind_param("sssssssi", $school_name, $contact_number, $email, $address, $established_year, $students_count, $website_url, $pk_school_id);

        if ($stmt->execute()) {
            echo json_encode(1);
        } else {
            echo "Error executing statement: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Invalid request method";
    }
}




update_school($conn);
$conn->close();
