import React from 'react'

const AssignBooks = () => {


    const handleSubmit = () =>{

    }

  return (
    <div>
        <form onSubmit={handleSubmit}>
            <div className="input-field">
                <select name="" id="">
                    <option value=""></option>
                </select>
            </div>
        </form>
    </div>
  )

}

export default AssignBooks