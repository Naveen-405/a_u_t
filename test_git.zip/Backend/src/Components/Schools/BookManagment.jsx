import React, { useEffect, useState } from "react";
import * as Yup from "yup";
import { useFormik } from "formik";
import axios from "axios";
import { FaEdit, FaTrash } from "react-icons/fa";

const BookManagment = () => {
  const [isBookEditOpen, setIsBookEditOpen] = useState(false);
  const [booksData, setBooksData] = useState([]);
  const [currentBook, setCurrentBook] = useState(null);

  const fetchBooksData = () => {
    fetch("http://localhost/test_wp/Backend/get_book.php")
      .then((response) => response.json())
      .then((data) => {
        setBooksData(data);
      });
  };

  const refreshData = () => {
    fetchBooksData();
  };

  useEffect(() => {
    fetchBooksData();
  }, []);

  const handleDeleteBook = (id) => {};

  const handleEditBook = (book) => {
    setCurrentBook(book);
    setIsBookEditOpen(true);
  };

  const bookFormik = useFormik({
    initialValues: {
      book_name: "",
      author: "",
      published_year: "",
      genre: "",
      summary: "",
    },
    validationSchema: Yup.object({
      book_name: Yup.string().required("Book Name is required"),
      author: Yup.string().required("Author is required"),
      published_year: Yup.date().required("Published year is required"),
      genre: Yup.string().required("This field is required"),
      summary: Yup.string().required("Summary is required"),
    }),
    onSubmit: async (values) => {
      const formData = new FormData();
      formData.append("book_name", values.book_name);
      formData.append("author", values.author);
      formData.append("published_year", values.published_year);
      formData.append("genre", values.genre);
      formData.append("summary", values.summary);

      try {
        const response = await axios.post(
          "http://localhost/test_wp/Backend/add_book.php",
          formData
        );

        if (response.data === 1) {
          bookFormik.resetForm();
          setCurrentBook(null);
          setIsBookEditOpen(false);
          refreshData();
        } else {
          console.log("Error Submitting Book...");
        }
      } catch (error) {
        console.error(error);
      }
    },
  });

  useEffect(() => {
    if (currentBook) {
      bookFormik.setValues({
        book_name: currentBook.book_name,
        author: currentBook.author,
        published_year: currentBook.published_year,
        gener: currentBook.gener,
        summary: currentBook.summary,
      });
    }
    console.log(currentBook);
  }, [currentBook]);

  return (
    <div>
      <div
        className={`modal fade ${isBookEditOpen ? "show" : ""}`}
        style={{ display: isBookEditOpen ? "block" : "none" }}
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h2>Add Book</h2>
              <button
                type="button"
                className="btn-close"
                onClick={() => setIsBookEditOpen(false)}
              ></button>
            </div>
            <div className="modal-body">
              <form onSubmit={bookFormik.handleSubmit}>
                <div className="input-grp">
                  <label htmlFor="book_name" className="form-label">
                    Book Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    name="book_name"
                    value={bookFormik.values.book_name}
                    onChange={bookFormik.handleChange}
                    onBlur={bookFormik.handleBlur}
                  />
                  {bookFormik.touched.book_name &&
                  bookFormik.errors.book_name ? (
                    <div className="error text-danger">
                      {bookFormik.errors.book_name}
                    </div>
                  ) : null}
                </div>
                <div className="input-grp">
                  <label htmlFor="author" className="form-label">
                    Author
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    name="author"
                    value={bookFormik.values.author}
                    onChange={bookFormik.handleChange}
                    onBlur={bookFormik.handleBlur}
                  />
                  {bookFormik.touched.author && bookFormik.errors.author ? (
                    <div className="error text-danger">
                      {bookFormik.errors.author}
                    </div>
                  ) : null}
                </div>
                <div className="input-grp">
                  <label htmlFor="published_year" className="form-label">
                    published_year
                  </label>
                  <input
                    type="date"
                    className="form-control"
                    name="published_year"
                    value={bookFormik.values.published_year}
                    onChange={bookFormik.handleChange}
                    onBlur={bookFormik.handleBlur}
                  />
                  {bookFormik.touched.published_year &&
                  bookFormik.errors.published_year ? (
                    <div className="error text-danger">
                      {bookFormik.errors.published_year}
                    </div>
                  ) : null}
                </div>
                <div className="input-grp">
                  <label htmlFor="genre" className="form-label">
                    Genre
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    name="genre"
                    value={bookFormik.values.genre}
                    onChange={bookFormik.handleChange}
                    onBlur={bookFormik.handleBlur}
                  />
                  {bookFormik.touched.genre && bookFormik.errors.genre ? (
                    <div className="error text-danger">
                      {bookFormik.errors.genre}
                    </div>
                  ) : null}
                </div>
                <div className="input-grp">
                  <label htmlFor="summary" className="form-label">
                    Summary
                  </label>
                  <textarea
                    type="text"
                    className="form-control"
                    name="summary"
                    value={bookFormik.values.summary}
                    onChange={bookFormik.handleChange}
                    onBlur={bookFormik.handleBlur}
                  />
                  {bookFormik.touched.summary && bookFormik.errors.summary ? (
                    <div className="error text-danger">
                      {bookFormik.errors.summary}
                    </div>
                  ) : null}
                </div>
                <button type="submit" className="btn btn-dark mt-3">
                  Add book
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <table className="table table-striped table-hover">
        <thead className="table-dark">
          <tr>
            <th>Book Name</th>
            <th>Author</th>
            <th>Published Year</th>
            <th>Gener</th>
            <th>Summary</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {booksData.map((data, index) => (
            <tr key={index}>
              <td>{data.book_name}</td>
              <td>{data.author}</td>
              <td>{data.published_year}</td>
              <td>{data.gener}</td>
              <td>{data.summary}</td>
              <td>
                <FaEdit
                  onClick={() => handleEditBook(data)}
                  style={{ cursor: "pointer", fontSize: "18px" }}
                  title="Edit Book"
                  className="text-dark me-2"
                />
                <FaTrash
                  onClick={() => handleDeleteBook(data.id)}
                  style={{ cursor: "pointer", fontSize: "16px" }}
                  title="Delete Book"
                  className="text-danger"
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BookManagment;
