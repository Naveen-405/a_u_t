import React, { useEffect, useState } from "react";
import * as Yup from "yup";
import { useFormik } from "formik";
import axios from "axios";
import { FaEdit, FaTrash } from "react-icons/fa";
import Navbar from "../Common/Navbar";
import Select from "react-select";

const School = () => {
  const [schoolData, setSchoolData] = useState([]);
  const [currentSchool, setCurrentSchool] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isBookEditOpen, setIsBookEditOpen] = useState(false);
  const [booksData, setBooksData] = useState([]);
  const [showSchooltable, setShowSchoolTable] = useState(false);
  const [currentBook, setCurrentBook] = useState(null);

  const [selectedBooks, setSelectedBooks] = useState([]);

  const [booksAssign, setBookAssign] = useState([]);
  const [isOpenAssignBook, setIsOpenAssignBook] = useState(false);
  // const [selectedBooksMap, setSelectedBooksMap] = useState({});
  const [isSaved, setIsSaved] = useState({});

  const [selectedBooksMap, setSelectedBooksMap] = useState({});
  const [isEditing, setIsEditing] = useState({});
  const [assignedBooksMap, setAssignedBooksMap] = useState({});

  const fetchSchoolData = () => {
    fetch("http://localhost/test_wp/Backend/get_school.php")
      .then((response) => response.json())
      .then((data) => {
        setSchoolData(data);
      });
  };

  const fetchBooksData = () => {
    fetch("http://localhost/test_wp/Backend/get_book.php")
      .then((response) => response.json())
      .then((data) => {
        setBooksData(data);
        // Transform the fetched data to match the react-select options format
        const formattedData = data.map((book) => ({
          value: book.pk_book_id,
          label: book.book_name,
        }));
        setBookAssign(formattedData);
      });
  };

  useEffect(() => {
    fetchSchoolData();
    fetchBooksData();
  }, []);

  const refreshData = () => {
    fetchSchoolData();
    fetchBooksData();
  };

  const handleDeleteBook = async (pk_book_id) => {
    const formData = new FormData();
    formData.append("pk_book_id", pk_book_id);

    try {
      const response = await axios.post(
        "http://localhost/test_wp/Backend/delete_book.php",
        formData
      );
      if (response.data === 1) {
        console.log("Book deleted successfully");
        refreshData();
      }
    } catch (error) {
      console.error("Error Sumbiting data...", error);
    }
  };

  const handleEditBook = (book) => {
    setCurrentBook(book);
    setIsBookEditOpen(true);
  };

  const handleDeleteSchool = async (pk_school_id) => {
    const formData = new FormData();
    formData.append("pk_school_id", pk_school_id);

    if (window.confirm("Are you sure you want to delete this school?")) {
      console.log("Deleting school with ID:", pk_school_id);
      try {
        const response = await axios.post(
          "http://localhost/test_wp/Backend/delete_school.php",
          formData // send formData directly
        );

        // Check the response for success
        if (response.data === 1) {
          // Make sure to access data correctly
          console.log("School deleted successfully");
          refreshData(); // Refresh the data after successful deletion
        } else {
          console.log("There was an error while deleting...");
        }

        console.log("Delete response:", response.data);
      } catch (error) {
        console.error("Failed to delete school:", error);
        alert("Error deleting school. Please try again.");
      }
    }
  };

  const handleEditSchool = (school) => {
    setCurrentSchool(school);
    setIsEditModalOpen(true);
  };

  const validationSchema = Yup.object({
    school_name: Yup.string().required("School Name is required"),
    contact_number: Yup.string()
      .required("Contact number is required")
      .matches(/^[0-9]*$/, "Contact number must be numeric"),
    email: Yup.string()
      .required("Email is required")
      .email("Invalid email format"),
    address: Yup.string().required("Address is required"),
    established_year: Yup.string().required("Established Year is required"),
    students_count: Yup.number()
      .required("Student Count is required")
      .positive("Must be a positive number")
      .integer("Must be an integer"),
    website_url: Yup.string()
      .required("Website URL is required")
      .url("Invalid URL format"),
  });

  const formik = useFormik({
    initialValues: {
      school_name: "",
      contact_number: "",
      email: "",
      address: "",
      established_year: "",
      students_count: "",
      website_url: "",
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      const formData = new FormData();

      formData.append("school_name", values.school_name);
      formData.append("contact_number", values.contact_number);
      formData.append("email", values.email);
      formData.append("address", values.address);
      formData.append("established_year", values.established_year);
      formData.append("students_count", values.students_count);
      formData.append("website_url", values.website_url);

      try {
        if (currentSchool) {
          // If updating, include the ID in the FormData
          formData.append("pk_school_id", currentSchool.pk_school_id);

          await axios.post(
            "http://localhost/test_wp/Backend/update_school.php",
            formData
          );
        } else {
          // Add new school
          await axios.post(
            "http://localhost/test_wp/Backend/add_school.php",
            formData
          );
        }
        formik.resetForm();
        setCurrentSchool(null);
        setIsEditModalOpen(false);
        refreshData();
      } catch (error) {
        console.error(error);
      }
    },
  });

  const bookFormik = useFormik({
    initialValues: {
      book_name: "",
      author: "",
      published_year: "",
      genre: "",
      summary: "",
    },
    validationSchema: Yup.object({
      book_name: Yup.string().required("Book Name is required"),
      author: Yup.string().required("Author is required"),
      published_year: Yup.date().required("Published year is required"),
      genre: Yup.string().required("This field is required"),
      summary: Yup.string().required("Summary is required"),
    }),
    onSubmit: async (values) => {
      const formData = new FormData();
      formData.append("book_name", values.book_name);
      formData.append("author", values.author);
      formData.append("published_year", values.published_year);
      formData.append("genre", values.genre);
      formData.append("summary", values.summary);

      try {
        if (currentBook) {
          formData.append("pk_book_id", currentBook.pk_book_id);

          await axios.post(
            "http://localhost/test_wp/Backend/update_book.php",
            formData
          );
        } else {
          const response = await axios.post(
            "http://localhost/test_wp/Backend/add_book.php",
            formData
          );
        }
        bookFormik.resetForm();
        setCurrentBook(null);
        setIsBookEditOpen(false);
        refreshData();
      } catch (error) {
        console.error("Error submitting data", error);
      }
    },
  });

  useEffect(() => {
    if (currentBook && Object.keys(currentBook).length > 0) {
      bookFormik.setValues({
        book_name: currentBook.book_name,
        author: currentBook.author,
        published_year: currentBook.published_year,
        genre: currentBook.genre, // Corrected
        summary: currentBook.summary,
      });
    }
  }, [currentBook]);

  useEffect(() => {
    if (currentSchool) {
      formik.setValues({
        school_name: currentSchool.school_name,
        contact_number: currentSchool.contact_number,
        email: currentSchool.email,
        address: currentSchool.address,
        established_year: currentSchool.established_year,
        students_count: currentSchool.students_count,
        website_url: currentSchool.website_url,
      });
    }
  }, [currentSchool]);

  const handleClose = () => {
    setIsBookEditOpen(false);
    setCurrentBook(null);
    bookFormik.resetForm();
    formik.resetForm();
    setIsEditModalOpen(false);
  };

  const saveAssignedBooks = async (schoolId, books) => {
    const apiUrl = "http://localhost/test_wp/Backend/assign_book.php";

    // Perform the API request
    const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
            school_id: schoolId,
            books: JSON.stringify(books)
        })
    });

    if (!response.ok) {
        throw new Error("Failed to save books");
    }

    const data = await response.json();
    console.log(data); // Check the server's response

    return data;
};

  // Handle book selection for a specific school

  // Handle book selection for a specific school
  const handleBookChange = (selectedOptions, schoolId) => {
    setSelectedBooksMap((prev) => ({
      ...prev,
      [schoolId]: selectedOptions || [],
    }));
  };

  // Save assigned books for a specific school
  const handleSaveBooks = async (schoolId) => {
    console.log(schoolId);
    
    const selectedBooks = selectedBooksMap[schoolId] || [];

    try {
      
      await saveAssignedBooks(schoolId, selectedBooks);

      // Update the assignedBooksMap after successful assignment
      setAssignedBooksMap((prev) => ({
        ...prev,
        [schoolId]: selectedBooks,
      }));

      // Set isEditing to false after saving
      setIsEditing((prev) => ({
        ...prev,
        [schoolId]: false,
      }));
    } catch (error) {
      console.error("Failed to save assigned books:", error);
    }
  };

  // Enable editing mode for a specific school
  const handleEditClick = (schoolId) => {
    setIsEditing((prev) => ({
      ...prev,
      [schoolId]: true,
    }));
  };

  return (
    <div className="container-fluid">
      <div className="">
        <Navbar />
        <section className="school-list">
          <div className="d-flex justify-content-between align-items-center mt-4 ">
            <h1 className="fw-bold">SL</h1>
            <div className="d-flex gap-2 ">
              <button
                className="btn btn-dark"
                onClick={() => {
                  setCurrentBook(null);
                  setIsBookEditOpen(true);
                }}
              >
                Add Book
              </button>
              <button
                className="btn btn-dark"
                onClick={() => {
                  setCurrentSchool(null);
                  setIsEditModalOpen(true);
                }}
              >
                Add School
              </button>
              <button
                className="btn btn-dark"
                onClick={() => {
                  setIsOpenAssignBook(true);
                }}
              >
                Assign Book
              </button>
            </div>
          </div>

          <div
            className={`modal fade ${isBookEditOpen ? "show" : ""}`}
            style={{ display: isBookEditOpen ? "block" : "none" }}
          >
            <div className="modal-dialog">
              <div className="modal-content">
                <div className="modal-header">
                  <h2>Add Book</h2>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={handleClose}
                  ></button>
                </div>
                <div className="modal-body">
                  <form onSubmit={bookFormik.handleSubmit}>
                    <div className="input-grp">
                      <label htmlFor="book_name" className="form-label">
                        Book Name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        name="book_name"
                        value={bookFormik.values.book_name}
                        onChange={bookFormik.handleChange}
                        onBlur={bookFormik.handleBlur}
                      />
                      {bookFormik.touched.book_name &&
                      bookFormik.errors.book_name ? (
                        <div className="error text-danger">
                          {bookFormik.errors.book_name}
                        </div>
                      ) : null}
                    </div>
                    <div className="input-grp">
                      <label htmlFor="author" className="form-label">
                        Author
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        name="author"
                        value={bookFormik.values.author}
                        onChange={bookFormik.handleChange}
                        onBlur={bookFormik.handleBlur}
                      />
                      {bookFormik.touched.author && bookFormik.errors.author ? (
                        <div className="error text-danger">
                          {bookFormik.errors.author}
                        </div>
                      ) : null}
                    </div>
                    <div className="input-grp">
                      <label htmlFor="published_year" className="form-label">
                        published_year
                      </label>
                      <input
                        type="date"
                        className="form-control"
                        name="published_year"
                        value={bookFormik.values.published_year}
                        onChange={bookFormik.handleChange}
                        onBlur={bookFormik.handleBlur}
                      />
                      {bookFormik.touched.published_year &&
                      bookFormik.errors.published_year ? (
                        <div className="error text-danger">
                          {bookFormik.errors.published_year}
                        </div>
                      ) : null}
                    </div>
                    <div className="input-grp">
                      <label htmlFor="genre" className="form-label">
                        Genre
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        name="genre"
                        value={bookFormik.values.genre}
                        onChange={bookFormik.handleChange}
                        onBlur={bookFormik.handleBlur}
                      />
                      {bookFormik.touched.genre && bookFormik.errors.genre ? (
                        <div className="error text-danger">
                          {bookFormik.errors.genre}
                        </div>
                      ) : null}
                    </div>
                    <div className="input-grp">
                      <label htmlFor="summary" className="form-label">
                        Summary
                      </label>
                      <textarea
                        type="text"
                        className="form-control"
                        name="summary"
                        value={bookFormik.values.summary}
                        onChange={bookFormik.handleChange}
                        onBlur={bookFormik.handleBlur}
                      />
                      {bookFormik.touched.summary &&
                      bookFormik.errors.summary ? (
                        <div className="error text-danger">
                          {bookFormik.errors.summary}
                        </div>
                      ) : null}
                    </div>
                    <button type="submit" className="btn btn-dark mt-3">
                      Add book
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>

          {/* Add/Edit School Modal */}
          <div
            className={`modal fade ${isEditModalOpen ? "show" : ""}`}
            style={{ display: isEditModalOpen ? "block" : "none" }}
          >
            <div className="modal-dialog">
              <div className="modal-content">
                <div className="modal-header">
                  <h1 className="modal-title fs-5">
                    {currentSchool ? "Edit School" : "Add School"}
                  </h1>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={handleClose}
                  ></button>
                </div>
                <div className="modal-body">
                  <form onSubmit={formik.handleSubmit}>
                    {/* School Name */}
                    <div className="input-grp">
                      <label htmlFor="school_name" className="form-label">
                        School Name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        name="school_name"
                        value={formik.values.school_name}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.school_name &&
                      formik.errors.school_name ? (
                        <div className="error text-danger">
                          {formik.errors.school_name}
                        </div>
                      ) : null}
                    </div>

                    {/* Contact Number */}
                    <div className="input-grp">
                      <label htmlFor="contact_number" className="form-label">
                        Contact Number
                      </label>
                      <input
                        type="tel"
                        className="form-control"
                        name="contact_number"
                        value={formik.values.contact_number}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.contact_number &&
                      formik.errors.contact_number ? (
                        <div className="error text-danger">
                          {formik.errors.contact_number}
                        </div>
                      ) : null}
                    </div>

                    {/* Email */}
                    <div className="input-grp">
                      <label htmlFor="email" className="form-label">
                        Email
                      </label>
                      <input
                        type="email"
                        className="form-control"
                        name="email"
                        value={formik.values.email}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.email && formik.errors.email ? (
                        <div className="error text-danger">
                          {formik.errors.email}
                        </div>
                      ) : null}
                    </div>

                    {/* Address */}
                    <div className="input-grp">
                      <label htmlFor="address" className="form-label">
                        Address
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        name="address"
                        value={formik.values.address}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.address && formik.errors.address ? (
                        <div className="error text-danger">
                          {formik.errors.address}
                        </div>
                      ) : null}
                    </div>

                    {/* Established Year */}
                    <div className="input-grp">
                      <label htmlFor="established_year" className="form-label">
                        Established Year
                      </label>
                      <input
                        type="date"
                        className="form-control"
                        name="established_year"
                        value={formik.values.established_year}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.established_year &&
                      formik.errors.established_year ? (
                        <div className="error text-danger">
                          {formik.errors.established_year}
                        </div>
                      ) : null}
                    </div>

                    {/* Students Count */}
                    <div className="input-grp">
                      <label htmlFor="students_count" className="form-label">
                        Students Count
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        name="students_count"
                        value={formik.values.students_count}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.students_count &&
                      formik.errors.students_count ? (
                        <div className="error text-danger">
                          {formik.errors.students_count}
                        </div>
                      ) : null}
                    </div>

                    {/* Website URL */}
                    <div className="input-grp">
                      <label htmlFor="website_url" className="form-label">
                        Website URL
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        name="website_url"
                        value={formik.values.website_url}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.website_url &&
                      formik.errors.website_url ? (
                        <div className="error text-danger">
                          {formik.errors.website_url}
                        </div>
                      ) : null}
                    </div>

                    <div className="btn-grp d-flex justify-content-end align-items-center mt-4">
                      <button
                        type="submit"
                        onClick={refreshData}
                        className="btn btn-outline-dark"
                      >
                        Submit
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div className="container-fluid mt-5">
            <div className="form-grp mb-3 d-flex gap-2">
              <div className="div-2">
                <input
                  type="radio"
                  name="table"
                  className="form-check-input"
                  checked={showSchooltable}
                  onChange={() => setShowSchoolTable(true)}
                />
                <label className="ms-1 form-check-label">School Table</label>
              </div>
              <div className="div-1">
                <input
                  type="radio"
                  name="table"
                  className="form-check-input"
                  checked={!showSchooltable}
                  onChange={() => setShowSchoolTable(false)}
                />
                <label className="ms-1 form-check-label">Book Table</label>
              </div>
            </div>

            <div className="row">
              <div className="col-md-12">
                <div className="table-responsive ">
                  {showSchooltable ? (
                    <table className="table table-striped table-hover">
                      <thead className="table-dark">
                        <tr>
                          <th>School Name</th>
                          <th>Contact Number</th>
                          <th>Email</th>
                          <th>Address</th>
                          <th>Established Year</th>
                          <th>Students Count</th>
                          <th>Assign Books</th>
                          <th>Website URL</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {schoolData.map((data, index) => (
                          <tr key={index}>
                            <td>{data.school_name}</td>
                            <td>{data.contact_number}</td>
                            <td>{data.email}</td>
                            <td>{data.address}</td>
                            <td>{data.established_year}</td>
                            <td>{data.students_count}</td>
                            <td>
                              {isEditing[data.pk_school_id] ||
                              !assignedBooksMap[data.pk_school_id] ? (
                                <form onSubmit={(e) => e.preventDefault()}>
                                  <Select
                                    isMulti
                                    options={booksAssign}
                                    value={
                                      selectedBooksMap[data.pk_school_id] || []
                                    }
                                    onChange={(selectedOptions) =>
                                      handleBookChange(
                                        selectedOptions,
                                        data.pk_school_id
                                      )
                                    }
                                    placeholder="Select books..."
                                    className="multi-select"
                                  />
                                  <button
                                    type="button"
                                    className="btn btn-dark mt-2"
                                    onClick={() =>
                                      handleSaveBooks(data.pk_school_id)
                                    }
                                  >
                                    Save
                                  </button>
                                </form>
                              ) : (
                                <div>
                                  <ul>
                                    {assignedBooksMap[data.pk_school_id].map(
                                      (book) => (
                                        <li key={book.value}>{book.label}</li>
                                      )
                                    )}
                                  </ul>
                                  <button
                                    type="button"
                                    className="btn btn-secondary mt-2"
                                    onClick={() =>
                                      handleEditClick(data.pk_school_id)
                                    }
                                  >
                                    Edit
                                  </button>
                                </div>
                              )}
                            </td>
                            <td>{data.website_url}</td>
                            <td>
                              <FaEdit
                                onClick={() => handleEditSchool(data)}
                                style={{ cursor: "pointer", fontSize: "18px" }}
                                title="Edit School"
                                className="text-dark me-2"
                              />
                              <FaTrash
                                onClick={() =>
                                  handleDeleteSchool(data.pk_school_id)
                                }
                                style={{ cursor: "pointer", fontSize: "16px" }}
                                title="Delete School"
                                className="text-danger"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <table className="table table-striped table-hover">
                      <thead className="table-dark">
                        <tr>
                          <th>Book Name</th>
                          <th>Author</th>
                          <th>Published Year</th>
                          <th>Gener</th>
                          <th>Summary</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {booksData.map((data, index) => (
                          <tr key={index}>
                            <td>{data.book_name}</td>
                            <td>{data.author}</td>
                            <td>{data.published_year}</td>
                            <td>{data.genre}</td>
                            <td>{data.summary}</td>
                            <td>
                              <FaEdit
                                onClick={() => handleEditBook(data)}
                                style={{ cursor: "pointer", fontSize: "18px" }}
                                title="Edit Book"
                                className="text-dark me-2"
                              />
                              <FaTrash
                                onClick={() =>
                                  handleDeleteBook(data.pk_book_id)
                                }
                                style={{ cursor: "pointer", fontSize: "16px" }}
                                title="Delete Book"
                                className="text-danger"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default School;
