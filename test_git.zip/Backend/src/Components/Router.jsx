import React from 'react';
import { BrowserRouter, Routes, Route} from 'react-router-dom';

// Components
import School from "./Schools/School";
import Navbar from './Common/Navbar';

const Router = () => {
  return (
    <>
        <BrowserRouter>
      
            <Routes>
                <Route path='/school-list' element={<School/>} />
            </Routes>
        </BrowserRouter>
    </>
  )
}

export default Router