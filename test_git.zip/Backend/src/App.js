import logo from './logo.svg';
import './App.css';
import Router from './Components/Router';

function App() {
  return (
    <div className="App">
     <Router/>
    </div>
  );
}

export default App;
