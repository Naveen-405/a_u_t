<?php
include "config.php";

function delete_book($conn)
{
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $pk_book_id = (int)($_POST['pk_book_id'] ?? 0);

        if ($pk_book_id <= 0) {
            echo json_encode(["status" => "error", "message" => "Invalid book ID"]);
            return;
        }

        $stmt = $conn->prepare("DELETE FROM books WHERE pk_book_id = ?");
        $stmt->bind_param("i", $pk_book_id);

        if ($stmt->execute()) {
            echo json_encode(1);
        } else {
            echo json_encode(0);
        }

        $stmt->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    }
}
delete_book($conn)

?>